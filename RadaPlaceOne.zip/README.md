# Rada PlaceOne Web3/React Project

1. npm install on root folder

2. cd client

3. npm install

4. cd ..

5. npm run dev

# How to contribute

1. create new branch

2. create Pull Request

# Node version

16.20.0
